﻿$(document).ready(function () {
    $('#tableEmployee,#EmP').DataTable({
        dom: 'lBfrtip',
        buttons:[
            'copy', 'csv', 'excel', 'pdf', 'print', 'colvis'
        ],
        "scrollY": "450px",
        "scrollCollapse": true,
        "paging": true
    });
});
